BAHAba logo (symbol only, no text)
Idea: a rooftop that stays above rising water, with a white droplet inside the roof.

bahaba-logo.svg / logo-512.png / logo-1024.png - the logo: rounded teal tile with the symbol (headers, welcome/login page, social)
bahaba-symbol-color.svg / symbol-color-512.png - bare symbol in navy + teal on transparent, for light backgrounds
bahaba-app-icon.svg / app-icon-1024.png - square full-bleed icon (Android/iOS source icon)
bahaba-icon-foreground.svg / icon-foreground-1024.png - transparent symbol for the Android adaptive icon (background colour #0E93AE)
favicon-32/64/192.png - website favicons

Colours: teal #14B4CF -> #0A6B88, white, aqua #9BEBFA, navy #0B3C5D, teal #0A93AE.
